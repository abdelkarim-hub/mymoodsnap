
    let itemsPerPage = 20;
    let currentPage = 1;
    let moodChart;

    function logMood() {
        const moodInput = document.getElementById('moodInput').value;
        if (!moodInput) {
            alert('Please enter your mood!');
            return;
        }
        const moodHistory = document.getElementById('moodHistory');
        const listItem = document.createElement('li');
        listItem.textContent = `${new Date().toLocaleDateString()} - ${moodInput}`;
        moodHistory.appendChild(listItem);
        saveMoodToStorage(moodInput);
        updateMoodChart();
        document.getElementById('moodInput').value = '';
    }

    function saveMoodToStorage(mood) {
        const moods = JSON.parse(localStorage.getItem('moods')) || [];
        moods.push({ date: new Date().toLocaleDateString(), mood });
        localStorage.setItem('moods', JSON.stringify(moods));
    }

    function getMoodsFromStorage() {
        return JSON.parse(localStorage.getItem('moods')) || [];
    }

    function displayMoodHistory() {
        const moods = getMoodsFromStorage();
        const moodHistory = document.getElementById('moodHistory');
        moodHistory.innerHTML = '';
        const startIndex = 0;
        const endIndex = itemsPerPage * currentPage;
        const moodsToDisplay = moods.slice(-endIndex).reverse();

        moodsToDisplay.forEach(item => {
            const listItem = document.createElement('li');
            listItem.textContent = `${item.date} - ${item.mood}`;
            moodHistory.appendChild(listItem);
        });

        if (endIndex < moods.length) {
            document.getElementById('loadMoreBtn').style.display = 'block';
        } else {
            document.getElementById('loadMoreBtn').style.display = 'none';
        }
    }

    function loadMoreHistory() {
        currentPage++;
        displayMoodHistory();
    }

    function getiOSVersion() {
        const ua = navigator.userAgent;
        const iOS = ua.match(/(iPad|iPhone|iPod).*OS (\d+)_/i);
        if (iOS) {
            return parseInt(iOS[2], 10);
        }
        return null;
    }

    function checkiOSSupport() {
        const iOSVersion = getiOSVersion();
        if (iOSVersion && iOSVersion < 13) {
            alert('Note: Some features may not work optimally on iOS versions below 13.');
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        checkiOSSupport();
        displayMoodHistory();
        updateMoodChart();
        document.getElementById('loadMoreBtn').addEventListener('click', loadMoreHistory);
    });
    