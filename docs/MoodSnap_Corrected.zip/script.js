
    let itemsPerPage = 20;
    let currentPage = 1;

    function logMood() {
        const moodInput = document.getElementById('moodInput').value;
        if (!moodInput) {
            alert('Please enter your mood!');
            return;
        }
        const moodHistory = document.getElementById('moodHistory');
        const listItem = document.createElement('li');
        listItem.textContent = `${new Date().toLocaleDateString()} - ${moodInput}`;
        moodHistory.appendChild(listItem);
        saveMoodToStorage(moodInput);
        document.getElementById('moodInput').value = '';
    }

    function saveMoodToStorage(mood) {
        const moods = JSON.parse(localStorage.getItem('moods')) || [];
        moods.push({ date: new Date().toLocaleDateString(), mood });
        localStorage.setItem('moods', JSON.stringify(moods));
    }

    function getMoodsFromStorage() {
        return JSON.parse(localStorage.getItem('moods')) || [];
    }

    document.addEventListener('DOMContentLoaded', () => {
        const moods = getMoodsFromStorage();
        const moodHistory = document.getElementById('moodHistory');
        moods.forEach(item => {
            const listItem = document.createElement('li');
            listItem.textContent = `${item.date} - ${item.mood}`;
            moodHistory.appendChild(listItem);
        });
    });
    