
    let itemsPerPage = 20;
    let currentPage = 1;
    let moodChart;

    function logMood() {
        const moodInput = document.getElementById('moodInput').value;
        if (!moodInput) {
            alert('Please enter your mood!');
            return;
        }
        const moodHistory = document.getElementById('moodHistory');
        const listItem = document.createElement('li');
        listItem.textContent = `${new Date().toLocaleDateString()} - ${moodInput}`;
        moodHistory.appendChild(listItem);
        saveMoodToStorage(moodInput);
        document.getElementById('moodInput').value = '';
        updateMoodChart();
    }

    function saveMoodToStorage(mood) {
        const moods = JSON.parse(localStorage.getItem('moods')) || [];
        moods.push({ date: new Date().toLocaleDateString(), mood });
        localStorage.setItem('moods', JSON.stringify(moods));
    }

    function getMoodsFromStorage() {
        return JSON.parse(localStorage.getItem('moods')) || [];
    }

    function displayMoodHistory() {
        const moods = getMoodsFromStorage();
        const moodHistory = document.getElementById('moodHistory');
        moodHistory.innerHTML = '';
        const startIndex = 0;
        const endIndex = itemsPerPage * currentPage;
        const moodsToDisplay = moods.slice(-endIndex).reverse();

        moodsToDisplay.forEach(item => {
            const listItem = document.createElement('li');
            listItem.textContent = `${item.date} - ${item.mood}`;
            moodHistory.appendChild(listItem);
        });

        if (endIndex < moods.length) {
            document.getElementById('loadMoreBtn').style.display = 'block';
        } else {
            document.getElementById('loadMoreBtn').style.display = 'none';
        }
    }

    function updateMoodChart() {
        const moods = getMoodsFromStorage();
        const moodCounts = moods.reduce((counts, mood) => {
            counts[mood.mood] = (counts[mood.mood] || 0) + 1;
            return counts;
        }, {});

        const labels = Object.keys(moodCounts);
        const data = Object.values(moodCounts);

        if (moodChart) {
            moodChart.destroy();
        }

        const ctx = document.getElementById('moodChart').getContext('2d');
        moodChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Mood Count',
                    data: data,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    document.addEventListener('DOMContentLoaded', () => {
        displayMoodHistory();
        updateMoodChart();
        document.getElementById('loadMoreBtn').addEventListener('click', () => {
            currentPage++;
            displayMoodHistory();
        });
    });
    